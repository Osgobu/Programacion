#1.crear una clase
#2.1.crear una funcion que ordene una lista de nombres 

class StrinsUtils:
    def ordenacio(self, lista:str)->None:
        