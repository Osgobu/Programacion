#1.crear una clase para las funcion
#2.1.hacer una funcion que encuentre elnumero mas pequeño de una lista

class orden:
    def 