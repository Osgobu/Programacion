#1.Crear un clase llamada sorting
#2.1 Crear una funcion que que ordene una lista 
from stats import Statistics
class Sorting:
    def __init__(self):
        self sorting=Sorting()
    def llista_nombres(self) -> None:
        if nombres in self.stats.keys():
            self.stats(nombres) 
            print("El nombre es mes petit")
        else:
            self.stats(nombre) 
            print("El nombre es major")
