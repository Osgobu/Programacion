#1.ordenar una lista
#2.1 Mostrar en pantalla 
#2.1.1.Crear una interficie clara y y ammigable con el usuario


from Sorting import Sorting:

def orden(self, lista:int)->None:
print("Este es el orden de los numeros que usted a introducido")