#1.Crear una clase de Statistics
#2.1.Calcular la desviacion estandar

#Esta clase lo qeu tendria que hacer es tenr una funcion 
class Statistics:
    #Esta funcion tendria que hacer una desviacion estandar para ver los numeros que introduce el cliente
    def desviacio(self) -> None:
        
    


